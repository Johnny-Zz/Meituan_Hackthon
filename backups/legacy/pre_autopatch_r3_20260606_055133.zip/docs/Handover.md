# Handover.md

用于交接 MeituanRSD_autosolver 当前 champion、candidate、风险分支、训练轮次、备份点与下一轮建议。

## 当前状态

- 项目名称：MeituanRSD_autosolver
- 当前 champion：716.74（仅作为 UI 内置参考值；真实成绩以本地/官方反馈为准）
- 保护场景：small_seed100、tiny_seed42、scarce_couriers_seed401
- 一键训练：已配置为训练前自动备份，随后写入 `memory/trials.jsonl`、`logs/training_rounds.jsonl`、`memory/agent_logs.jsonl`、`docs/Notes.md`、`docs/Handover.md`
- 回滚：在“回滚”模块选择备份版本，二次确认输入 `ROLLBACK` 后恢复

## 下一轮建议

1. V6 anchor-preserving：任何新分支不能丢掉 V4-A 已有收益。
2. high_noise：主拓扑多轮不动，下一步只改 backup list / backup order。
3. medium202：固定 champion 解后做小范围 output-level swap。
4. large302：暂缓，等待 hard lock 与 anchor fallback 框架稳定。


## Handover · Round 1 · 2026-06-06 05:11:04

- 项目：MeituanRSD_autosolver
- 本轮改动：initial validation round after implementing 10 requested UI/training/rollback changes
- 一键训练模式：dry_run
- 备份：backups/pre_train_r1_20260606_051104.zip
- 当前建议：继续保持 V6 anchor-preserving；high_noise 只改 backup_order，medium202 只做 output-level swap，large302 暂缓。
- 风险提醒：如果 protected case 触发退化，直接在“回滚”页选择上一轮 pre_train 备份并输入 ROLLBACK。


## Handover · Round 2 · 2026-06-06 05:30:55

- 项目：MeituanRSD_autosolver
- 本轮改动：integrate local_test, large_seed301 and original single-agent solver
- 一键训练模式：local_test
- 备份：backups/pre_train_r2_20260606_053044.zip
- 当前建议：继续保持 V6 anchor-preserving；high_noise 只改 backup_order，medium202 只做 output-level swap，large302 暂缓。
- 风险提醒：如果 protected case 触发退化，直接在“回滚”页选择上一轮 pre_train 备份并输入 ROLLBACK。
