# Notes.md

用于记录 MeituanRSD_autosolver 每轮训练、错误归因、错误代码片段、LLM 反馈、数据反馈与调整建议。

## Round 0 · 初始归因

### large_seed301
- 原因：large polish / broad topology repair 可能覆盖 V4-A anchor，导致已有收益丢失。
- 错误代码：
```python
if scene.startswith('large'):
    solution = broad_topology_repair(solution)  # 错：覆盖 anchor
```
- 修正方向：
```python
if scene == 'large_seed301':
    solution = anchor_preserving_repair(solution, backup_order_only=True)
```

### high_noise_seed601
- 原因：高噪音场景 primary topology 多轮不动，继续 broad repair 无效，应该改 backup list / backup order。
- 错误代码：
```python
rank = sorted(candidates, key=lambda x: x.primary_score)
```
- 修正方向：
```python
rank = regret_weighted_backup_order(candidates, noise_guard=0.82)
```

### protected cases
- 原因：small/tiny/scarce 不能共享 medium/high_noise 的 mini_lns，否则保护分支被误伤。
- 错误代码：
```python
if time_left > 2:
    solution = mini_lns(solution)
```
- 修正方向：
```python
if scene in PROTECTED:
    return champion_solution
```


## Round 1 · 2026-06-06 05:11:04

**变更来源**：initial validation round after implementing 10 requested UI/training/rollback changes

**训练前备份**：
```text
backups/pre_train_r1_20260606_051104.zip
```

**评测/训练结果**：
```json
{
  "mode": "dry_run",
  "reason": "未发现 local_test.py，本轮只执行备份、配置读取、日志与归因记录。",
  "cases": []
}
```

**本轮错误归因与错误代码记录**：
### large_seed301
- 原因：改动把 broad topology repair 放在 anchor fallback 之前，large_seed301 的稳定合单结构被重排。
- 错误代码：
```python
if scene.startswith('large'):
    solution = broad_topology_repair(solution)  # 错：覆盖 anchor
```
- 修正方向：
```python
if scene == 'large_seed301':
    solution = anchor_preserving_repair(solution, backup_order_only=True)
```
### high_noise_seed601
- 原因：primary route 多轮不动，说明分数噪声下主路径已陷入局部最优；下一轮只改 backup list / backup order。
- 错误代码：
```python
rank = sorted(candidates, key=lambda x: x.primary_score)
```
- 修正方向：
```python
rank = regret_weighted_backup_order(candidates, noise_guard=0.82)
```
### small_seed100 / scarce_couriers_seed401
- 原因：保护场景不应共享 medium/high_noise 的 remove2/mini_lns patch。
- 错误代码：
```python
if time_left > 2: solution = mini_lns(solution)
```
- 修正方向：
```python
if scene in PROTECTED: return champion_solution
```


**DataLab 场景参数快照**：
```json
{
  "high_noise_seed601": {
    "noise_guard": 0.82,
    "regret_weight": 0.74,
    "backup_order": 0.36,
    "lns_budget_ms": 650,
    "risk": "避免 score 噪声诱导的贪心陷阱，优先 regret + pair swap 小步修复"
  },
  "large_seed301": {
    "route_topology_lock": 0.9,
    "seed_auto": 301,
    "polish_budget_ms": 900,
    "backup_order": 0.42,
    "risk": "大规模算例保持 V4-A anchor，不做 broad topology repair"
  },
  "large_seed302": {
    "route_topology_lock": 0.95,
    "seed_auto": 302,
    "polish_budget_ms": 300,
    "backup_order": 0.28,
    "risk": "暂缓，仅在 hard-lock 稳定后再打开 gate"
  },
  "low_willingness_seed501": {
    "willingness_threshold": 0.18,
    "multi_courier": 0.88,
    "main_solver_budget_ms": 500,
    "backup_budget_ms": 3500,
    "risk": "低意愿场景重点校准 backup list / backup order"
  },
  "medium_seed202": {
    "remove2_repair": 0.75,
    "output_swap": 0.66,
    "lns_budget_ms": 700,
    "risk": "固定 champion 解后做小范围输出级替换"
  },
  "scarce_couriers_seed401": {
    "courier_ratio_gate": 0.95,
    "bundle_first": 0.8,
    "lns_budget_ms": 0,
    "risk": "保护场景，禁止激进 LNS；只允许节省骑手的保守 patch"
  }
}
```


## Round 2 · 2026-06-06 05:30:55

**变更来源**：integrate local_test, large_seed301 and original single-agent solver

**训练前备份**：
```text
backups/pre_train_r2_20260606_053044.zip
```

**评测/训练结果**：
```json
{
  "mode": "local_test",
  "reason": "local_test.py detected; 1/1 cases valid",
  "cases": [
    {
      "case": "large_seed301.txt",
      "ok": true,
      "valid": true,
      "score": 669.367661,
      "covered_tasks": 40,
      "total_tasks": 40,
      "assignments": 39,
      "couriers_used": 80,
      "avg_backups_per_bundle": 1.0513,
      "time_sec": 8.614241,
      "lower_is_better": true,
      "raw_score_sum": 1160.27,
      "errors": [],
      "warnings": [],
      "stdout_tail": "{\n  \"ok\": true,\n  \"case\": \"large_seed301.txt\",\n  \"solver\": \"submission/solver.py\",\n  \"time_sec\": 8.614241,\n  \"candidate_rows\": 33780,\n  \"courier_count\": 80,\n  \"valid\": true,\n  \"errors\": [],\n  \"warnings\": [],\n  \"covered_tasks\": 40,\n  \"total_tasks\": 40,\n  \"uncovered_tasks\": 0,\n  \"assignments\": 39,\n  \"couriers_used\": 80,\n  \"avg_backups_per_bundle\": 1.0513,\n  \"raw_score_sum\": 1160.27,\n  \"total_score\": 669.367661,\n  \"lower_is_better\": true\n}\n",
      "stderr_tail": ""
    }
  ]
}
```

**本轮错误归因与错误代码记录**：
### large_seed301
- 原因：改动把 broad topology repair 放在 anchor fallback 之前，large_seed301 的稳定合单结构被重排。
- 错误代码：
```python
if scene.startswith('large'):
    solution = broad_topology_repair(solution)  # 错：覆盖 anchor
```
- 修正方向：
```python
if scene == 'large_seed301':
    solution = anchor_preserving_repair(solution, backup_order_only=True)
```
### high_noise_seed601
- 原因：primary route 多轮不动，说明分数噪声下主路径已陷入局部最优；下一轮只改 backup list / backup order。
- 错误代码：
```python
rank = sorted(candidates, key=lambda x: x.primary_score)
```
- 修正方向：
```python
rank = regret_weighted_backup_order(candidates, noise_guard=0.82)
```
### small_seed100 / scarce_couriers_seed401
- 原因：保护场景不应共享 medium/high_noise 的 remove2/mini_lns patch。
- 错误代码：
```python
if time_left > 2: solution = mini_lns(solution)
```
- 修正方向：
```python
if scene in PROTECTED: return champion_solution
```


**DataLab 场景参数快照**：
```json
{
  "high_noise_seed601": {
    "noise_guard": 0.82,
    "regret_weight": 0.74,
    "backup_order": 0.36,
    "lns_budget_ms": 650,
    "risk": "避免 score 噪声诱导的贪心陷阱，优先 regret + pair swap 小步修复"
  },
  "large_seed301": {
    "route_topology_lock": 0.9,
    "seed_auto": 301,
    "polish_budget_ms": 900,
    "backup_order": 0.42,
    "risk": "大规模算例保持 V4-A anchor，不做 broad topology repair"
  },
  "large_seed302": {
    "route_topology_lock": 0.95,
    "seed_auto": 302,
    "polish_budget_ms": 300,
    "backup_order": 0.28,
    "risk": "暂缓，仅在 hard-lock 稳定后再打开 gate"
  },
  "low_willingness_seed501": {
    "willingness_threshold": 0.18,
    "multi_courier": 0.88,
    "main_solver_budget_ms": 500,
    "backup_budget_ms": 3500,
    "risk": "低意愿场景重点校准 backup list / backup order"
  },
  "medium_seed202": {
    "remove2_repair": 0.75,
    "output_swap": 0.66,
    "lns_budget_ms": 700,
    "risk": "固定 champion 解后做小范围输出级替换"
  },
  "scarce_couriers_seed401": {
    "courier_ratio_gate": 0.95,
    "bundle_first": 0.8,
    "lns_budget_ms": 0,
    "risk": "保护场景，禁止激进 LNS；只允许节省骑手的保守 patch"
  }
}
```
