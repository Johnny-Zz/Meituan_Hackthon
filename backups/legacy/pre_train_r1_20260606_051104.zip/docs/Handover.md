# Handover.md

用于交接 MeituanRSD_autosolver 当前 champion、candidate、风险分支、训练轮次、备份点与下一轮建议。

## 当前状态

- 项目名称：MeituanRSD_autosolver
- 当前 champion：716.74（仅作为 UI 内置参考值；真实成绩以本地/官方反馈为准）
- 保护场景：small_seed100、tiny_seed42、scarce_couriers_seed401
- 一键训练：已配置为训练前自动备份，随后写入 `memory/trials.jsonl`、`logs/training_rounds.jsonl`、`memory/agent_logs.jsonl`、`docs/Notes.md`、`docs/Handover.md`
- 回滚：在“回滚”模块选择备份版本，二次确认输入 `ROLLBACK` 后恢复

## 下一轮建议

1. V6 anchor-preserving：任何新分支不能丢掉 V4-A 已有收益。
2. high_noise：主拓扑多轮不动，下一步只改 backup list / backup order。
3. medium202：固定 champion 解后做小范围 output-level swap。
4. large302：暂缓，等待 hard lock 与 anchor fallback 框架稳定。
