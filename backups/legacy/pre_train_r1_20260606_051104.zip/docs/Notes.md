# Notes.md

用于记录 MeituanRSD_autosolver 每轮训练、错误归因、错误代码片段、LLM 反馈、数据反馈与调整建议。

## Round 0 · 初始归因

### large_seed301
- 原因：large polish / broad topology repair 可能覆盖 V4-A anchor，导致已有收益丢失。
- 错误代码：
```python
if scene.startswith('large'):
    solution = broad_topology_repair(solution)  # 错：覆盖 anchor
```
- 修正方向：
```python
if scene == 'large_seed301':
    solution = anchor_preserving_repair(solution, backup_order_only=True)
```

### high_noise_seed601
- 原因：高噪音场景 primary topology 多轮不动，继续 broad repair 无效，应该改 backup list / backup order。
- 错误代码：
```python
rank = sorted(candidates, key=lambda x: x.primary_score)
```
- 修正方向：
```python
rank = regret_weighted_backup_order(candidates, noise_guard=0.82)
```

### protected cases
- 原因：small/tiny/scarce 不能共享 medium/high_noise 的 mini_lns，否则保护分支被误伤。
- 错误代码：
```python
if time_left > 2:
    solution = mini_lns(solution)
```
- 修正方向：
```python
if scene in PROTECTED:
    return champion_solution
```
